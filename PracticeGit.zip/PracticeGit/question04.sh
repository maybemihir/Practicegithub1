git commit -m "Committing staged changes"
