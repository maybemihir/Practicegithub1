git fetch origin
git checkout branch2
git merge branch3
git add .
git commit -m "Merged branch3 into branch2 with conflict resolution"
git branch -d branch3
