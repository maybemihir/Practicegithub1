git checkout main
git merge branch1 -m "Merging branch1 into main"
