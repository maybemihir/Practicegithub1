git checkout branch2
git stash pop
git add file4
git commit -m "Restored and committed uncommitted changes to file4"
