git checkout -b submission-branch
rm question0*.sh
git add -u
git commit -m "Removed all .sh files for clean submission"
echo "This is file13 for submission." > file13.txt
git add file13.txt
git commit -m "Added file13.txt to submission branch"
git push origin submission-branch
