mkdir -p dir2
mv *.txt dir2/ 2>/dev/null
git add -A
git commit -m "Moved all .txt files to dir2 and committed the changes"
