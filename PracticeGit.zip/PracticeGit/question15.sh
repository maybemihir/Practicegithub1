git fetch origin
git checkout main
git merge origin/branch1
git add .
git commit -m "Merged branch1 into main with conflict resolution"
