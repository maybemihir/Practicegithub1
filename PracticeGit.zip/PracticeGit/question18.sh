git branch -r
git fetch --all
git checkout main
git pull origin main
for branch in $(git branch -r | grep 'origin/ready' | sed 's|origin/||'); do
  git checkout $branch
  git checkout main
  git merge $branch -m "Merged $branch into main"
  git branch -d $branch
done
for branch in $(git branch -r | grep 'origin/update' | sed 's|origin/||'); do
  git checkout $branch
  git merge main -m "Updated $branch with latest from main"
done
