git add *.py
git commit -m "Added and committed all Python files in the current directory"
