git add -u
git commit -m "Committing all modified files"
