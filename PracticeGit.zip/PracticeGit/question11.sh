git checkout -b branch2
echo "Initial content" > file4
git add file4
git commit -m "Added file4 in branch2"
echo "Modified content" >> file4
git stash
git checkout main
